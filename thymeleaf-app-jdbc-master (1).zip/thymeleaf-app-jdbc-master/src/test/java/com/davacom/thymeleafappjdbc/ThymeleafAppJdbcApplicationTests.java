package com.davacom.thymeleafappjdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafAppJdbcApplicationTests {

    @Test
    void contextLoads() {
    }

}
